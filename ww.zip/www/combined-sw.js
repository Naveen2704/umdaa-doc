importScripts('ngsw-worker.js');
importScripts('firebase-messaging-sw.js');
importScripts('sw.js');